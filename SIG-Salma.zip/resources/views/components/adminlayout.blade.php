<!DOCTYPE html>
<html lang="en">

<head>

    @include('components.navbarAdmin')
    @include('partials.head')
    @include('partials.font')
</head>

<body>
    {{ $slot }}

</body>

</html>
