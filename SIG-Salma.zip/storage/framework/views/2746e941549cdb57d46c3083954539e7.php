<?php if (isset($component)) { $__componentOriginal289312106351f198640d7154d055800b = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal289312106351f198640d7154d055800b = $attributes; } ?>
<?php $component = App\View\Components\Adminlayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('adminlayout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Adminlayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="w-full pt-10 pb-6 px-6">
        <div class="flex flex-col rounded-2xl overflow-hidden bg-white">
            <!-- Bagian atas menampilkan satu gambar secara acak -->
            <div class="relative">
                <?php if($randomLandingPage): ?>
                    <?php if($randomLandingPage->img): ?>
                        <div class="relative group">
                            <img src="<?php echo e(asset('storage/' . $randomLandingPage->img)); ?>"
                                class="object-cover w-full max-h-[600px] rounded-2xl" alt="Gambar">
                            <div
                                class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                <p class="text-white text-lg font-semibold"><?php echo e($randomLandingPage->nama_kursus); ?></p>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="flex items-center justify-center h-[600px] bg-gray-200 rounded-t-2xl">
                            <p class="text-gray-600">Tidak ada gambar yang tersedia.</p>
                        </div>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="py-10 flex col-span-3">
                        <div class="bg-[#EBFEA1] w-full poppins-extrabold m-auto flex items-center justify-center p-2">
                            <p>Tidak Tersedia Kursus</p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Bagian bawah menampilkan maksimal 6 gambar secara acak -->
            <div class="py-4">
                <div class="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-4">
                    <?php if($randomLandingPagess->isNotEmpty()): ?>
                        <?php $__currentLoopData = $randomLandingPagess; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div
                                class="relative group rounded-lg overflow-hidden shadow-md transition-transform transform hover:scale-105">
                                <img src="<?php echo e(asset('storage/' . $page->img)); ?>" class="object-cover w-full h-full"
                                    alt="">
                                <div
                                    class="absolute inset-0 bg-black bg-opacity-30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                    <p class="text-white text-lg font-semibold"><?php echo e($page->nama_kursus); ?></p>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php else: ?>
                        <div class="py-10 flex col-span-2 sm:col-span-3 md:col-span-4 lg:col-span-5">
                            <div class="bg-[#EBFEA1] w-full poppins-extrabold m-auto flex items-center justify-center p-2">
                                <p>Tidak Tersedia Kursus</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal289312106351f198640d7154d055800b)): ?>
<?php $attributes = $__attributesOriginal289312106351f198640d7154d055800b; ?>
<?php unset($__attributesOriginal289312106351f198640d7154d055800b); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal289312106351f198640d7154d055800b)): ?>
<?php $component = $__componentOriginal289312106351f198640d7154d055800b; ?>
<?php unset($__componentOriginal289312106351f198640d7154d055800b); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\SIG-Salma\resources\views/admin/dahsboard.blade.php ENDPATH**/ ?>