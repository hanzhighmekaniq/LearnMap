<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <style>
        #map1 { 
            max-width: 100%;
        }
    </style>
    <div class="container flex flex-col">
        <div class="py-10 bg-white">
            <div class="bg-[#EBFEA1] poppins-extrabold m-auto flex items-center justify-center p-2">
                <p>Halaman ini berisi tentang kursus di Pare!</p>
            </div>
        </div>
        <div class="pb-10">
            <!-- Peta Leaflet -->
            <div id="map1"
                class="w-full h-56 sm:h-64 md:h-96 lg:h-[500px] xl:h-[650px] max-w-4xl rounded-lg shadow-lg"></div>
        </div>
    </div>

    <!-- Leaflet CSS dan JS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
    <script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>

    <!-- Flowbite JS -->
    <script src="https://cdn.jsdelivr.net/npm/flowbite@2.5.1/dist/flowbite.min.js"></script>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Inisialisasi peta dengan koordinat dan tingkat zoom
            const map = L.map('map1').setView([-8.1675862,113.68492], 13); // Gunakan 'map1' untuk ID peta yang sesuai

            // Tambahkan lapisan ubin dari OpenStreetMap
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            }).addTo(map);

            // Menambahkan marker secara dinamis dengan data dari Blade
            <?php $__currentLoopData = $latilongti; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latilongti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                L.marker([<?php echo e($latilongti->latitude); ?>, <?php echo e($latilongti->longitude); ?>])
                    .addTo(map)
                    .bindPopup('<a href="/kursus/<?php echo e($latilongti->id); ?>/detail"><b><?php echo e($latilongti->nama_kursus); ?></b><br>Location: <?php echo e($latilongti->latitude); ?>, <?php echo e($latilongti->longitude); ?>')
                    .openPopup();
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        });
    </script>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>





<?php /**PATH C:\laragon\www\SIG-Salma\resources\views/user/peta.blade.php ENDPATH**/ ?>