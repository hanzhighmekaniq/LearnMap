<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-10 bg-white ">
        <div class="bg-[#EBFEA1] container poppins-extrabold m-auto flex items-center justify-center p-2">
            <p>Halaman ini berisi tentang kursus di Pare! </p>
        </div>
    </div>

    <div class="container flex justify-end items-center pb-16">
        <div id="default-carousel" class="relative w-full" data-carousel="slide">
            <!-- Carousel wrapper -->
            <div
                class="relative h-48 sm:h-[250px] md:h-[350px] lg:h-[450px] xl:h-[500px] 2xl:h-[600px] overflow-hidden rounded-lg">
                <?php if(!empty($imageNames) && count($imageNames) > 0): ?>
                    <?php $__currentLoopData = $imageNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $img_konten): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="hidden duration-1000 ease-in-out" data-carousel-item>
                            <img src="<?php echo e(asset('storage/' . $img_konten)); ?>"
                                class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                                alt="...">
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>
                    <div class="hidden duration-1000 ease-in-out" data-carousel-item>
                        <img src="https://via.placeholder.com/600x400"
                            class="absolute block w-full -translate-x-1/2 -translate-y-1/2 top-1/2 left-1/2"
                            alt="No image available">
                    </div>
                <?php endif; ?>
            </div>

            <!-- Slider indicators -->
            <div class="absolute z-30 flex -translate-x-1/2 bottom-5 left-1/2 space-x-3 rtl:space-x-reverse">
                <?php if(!empty($imageNames) && count($imageNames) > 0): ?>
                    <?php for($i = 0; $i < count($imageNames); $i++): ?>
                        <button type="button" class="w-3 h-3 rounded-full"
                            aria-current="<?php echo e($i === 0 ? 'true' : 'false'); ?>" aria-label="Slide <?php echo e($i + 1); ?>"
                            data-carousel-slide-to="<?php echo e($i); ?>"></button>
                    <?php endfor; ?>
                <?php else: ?>
                    <button type="button" class="w-3 h-3 rounded-full" aria-current="true"
                        aria-label="No slides available"></button>
                <?php endif; ?>
            </div>


            <!-- Slider controls -->
            <button type="button"
                class="absolute top-0 start-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                data-carousel-prev>
                <span
                    class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30 group-hover:bg-white/50 group-focus:ring-4 group-focus:ring-white group-focus:outline-none">
                    <svg class="w-4 h-4 text-white rtl:rotate-180" aria-hidden="true" xmlns="http://www.w3.org/2000/svg"
                        fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M5 1 1 5l4 4" />
                    </svg>
                    <span class="sr-only">Previous</span>
                </span>
            </button>

            <button type="button"
                class="absolute top-0 end-0 z-30 flex items-center justify-center h-full px-4 cursor-pointer group focus:outline-none"
                data-carousel-next>
                <span
                    class="inline-flex items-center justify-center w-10 h-10 rounded-full bg-white/30  group-hover:bg-white/50 group-focus:ring-4 group-focus:ring-white  group-focus:outline-none">
                    <svg class="w-4 h-4 text-white  rtl:rotate-180" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 6 10">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m1 9 4-4-4-4" />
                    </svg>
                    <span class="sr-only">Next</span>
                </span>
            </button>
        </div>
    </div>
    <div class="container">
        <p class="poppins-medium text-3xl xl:text-4xl text-black pb-4">Kampung Inggris LC - Language Center </p>
        <a href="/kursus/<?php echo e($data->id); ?>/rute" target="_blank"
            class="poppins-regular py-2 px-4 bg-[#4F7F81] text-white rounded-xl text-xl shadow-xl">Rute Terdekat</a>

        <p class="text-black text-2xl pt-10 xl:pt-16 poppins-semibold">Deskripsi</p>
        <p class="poppins-regular text-black text-2xl pb-2 max-w-7xl">
            <?php echo e($data->deskripsi); ?>

        </p>
        <div class="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-20 py-14">

            <div class="max-w-max space-y-2">
                <p class="poppins-semibold text-2xl text-black underline">
                    Paket
                </p>
                <h1 class="popins-reguler text-2xl text-black">
                    <?php echo $data->paket; ?>

                </h1>
            </div>
            <div class="max-w-max space-y-2">
                <p class="poppins-semibold text-2xl text-black underline">
                    Metode Pembelajaran
                </p>
                <h1 class="popins-reguler text-2xl text-black">
                    <?php echo $data->metode; ?>

                </h1>
                <p class="poppins-semibold text-2xl text-black pt-6 underline">
                    Fasilitas
                </p>
                <h1 class="popins-reguler text-2xl text-black">
                    <?php echo $data->fasilitas; ?>

                </h1>
            </div>
            <div class="max-w-max space-y-2">
                <p class="poppins-semibold text-2xl text-black underline">
                    Lokasi
                </p>
                <h1 class="popins-reguler text-2xl text-black">
                    <?php echo $data->lokasi; ?>

                </h1>
            </div>
        </div>

    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH C:\laragon\www\SIG-Salma\resources\views/user/detailKursus.blade.php ENDPATH**/ ?>