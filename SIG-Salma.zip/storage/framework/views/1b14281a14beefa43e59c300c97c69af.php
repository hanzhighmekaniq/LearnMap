<!DOCTYPE html>
<html lang="en">

<head>

    <?php echo $__env->make('components.navbarAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->make('partials.font', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</head>

<body>
    <?php echo e($slot); ?>


</body>

</html>
<?php /**PATH C:\laragon\www\SIG-Salma\resources\views/components/adminlayout.blade.php ENDPATH**/ ?>